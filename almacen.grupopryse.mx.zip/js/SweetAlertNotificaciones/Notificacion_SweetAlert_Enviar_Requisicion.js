document.addEventListener('DOMContentLoaded', function () { 
    const form = document.getElementById('FormularioEnviarRequisicion');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            const formData = new FormData(e.target);
            const submitButton = e.target.querySelector('button[type="submit"]');

            submitButton.disabled = true;

            fetch(e.target.action, {
                method: e.target.method,
                body: formData
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la comunicación con el servidor.');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: '¡Autorizado!',
                            text: data.message,
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => {
                            window.location.href = data.redirect || window.location.href;
                        });
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message
                        });
                    }
                })
                .catch(error => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Hubo un problema al procesar la solicitud.'
                    });
                    console.error(error);
                })
                .finally(() => {
                    submitButton.disabled = false;
                });
        });
    } else {
        console.error('FormularioAutorizarRequisicion no se encuentra en el DOM.');
    }
});