<?php
// Configuración inicial
header('Content-Type: application/json'); // Asegura que la respuesta sea JSON
ob_start(); // Limpia cualquier salida previa
session_start(); // Iniciar sesión
setlocale(LC_ALL, 'es_ES'); // Establece el idioma de la aplicación
date_default_timezone_set('America/Mexico_City'); // Establece la zona horaria de México

// Inclusión de archivos necesarios
include('../../../Modelo/Conexion.php'); // Conexión a la base de datos
require_once("../../../Modelo/Funciones/Funciones_Borrador_RequisicionD.php");
require_once("../../../Modelo/Funciones/Funciones_Borrador_RequisicionE.php");
require_once("../../../Modelo/Funciones/Funciones_RequisicionD.php");
require_once("../../../Modelo/Funciones/Funciones_RequisicionE.php");
require_once("../../../Modelo/Funciones/Funcion_TipoUsuario.php");
require_once('../../Reportes/Generar_Reporte_Solicitud_a_Gmail.php');
require_once('../../../librerias/PHPMailer/vendor/autoload.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Conexión a la base de datos
$conexion = (new Conectar())->conexion();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Id'])) {        
    // Obtiene la fecha y hora de creación de la requisición 
    $FchEnvio = date('Y-m-d H:i:s');
    $usuario = $_SESSION['usuario']; // Obtiene el usuario actualmente conectado

    // Validación de datos
    $BIDRequisicionE = $_POST['Id'];

    if (!$BIDRequisicionE) { // Verificar que los campos no estén vacíos
        echo json_encode([ // Devuelve un arreglo JSON con el mensaje de error
            "success" => false, // Indica que la operación no se realizó con éxito
            "message" => "Datos inválidos. Por favor, revise la información enviada."
        ]);
        exit; // Salir del script
    }

    // Comenzar la transacción
    $conexion->begin_transaction();

    try {
        // Obtener información del borrador de requisiciones
        $requisicionesE = SeleccionarInformacionBorradorRequisicionE($conexion, $BIDRequisicionE);
        $requisicionesD = SeleccionarInformacionBorradorRequisicionD($conexion, $BIDRequisicionE);

        if (!$requisicionesE) {
            throw new Exception('No se encontró información para la requisiciónE.');
        }

        if (!$requisicionesD) {
            throw new Exception('No se encontró información para la requisiciónD.');
        }

        // Crear nueva requisición en RequisicionE
        $idSolicitud = InsertarNuevaRequisicionE($conexion, $FchEnvio, $requisicionesE);

        if (!$idSolicitud) { // Verificar que la inserción se haya realizado correctamente
            throw new Exception('Error al insertar datos en la tabla RequisicionE.');
        }

        // Insertar detalles en RequisicionD
        $resultadoDetalles = InsertarNuevaRequisicionD($conexion, $idSolicitud, $requisicionesD);

        if (!$resultadoDetalles) { // Verificar que la inserción se haya realizado correctamente
            throw new Exception('Error al insertar detalles en la tabla RequisicionD.');
        }

        // Eliminar registros de los borradores
        EliminarRequisicionD($conexion, $BIDRequisicionE);
        EliminarRequisicionE($conexion, $BIDRequisicionE);

        // Enviar correo con la información
        $resultadoCorreo = enviarCorreo($FchEnvio, $idSolicitud, $conexion);

        if (is_array($resultadoCorreo) && $resultadoCorreo['success']) {
            throw new Exception('Error al enviar el correo: ' . $resultadoCorreo['message']);
        }

        // Confirmar la transacción
        $conexion->commit();

        $RetornarTipoUsuario = buscarYRetornarTipoUsuario($usuario, $conexion); // Buscar y retornar el tipo de usuario

        // Respuesta de éxito con la URL según tipo de usuario
        $urls = [
            1 => "../../../Vista/DEV/index_DEV.php", // URL para el tipo de usuario 1
            2 => "../../../Vista/SUPERADMIN/index_SUPERADMIN.php", // URL para el tipo de usuario 2
            3 => "../../../Vista/ADMIN/Solicitud_ADMIN.php", // URL para el tipo de usuario 3
            4 => "../../../Vista/USER/Solicitud_USER.php", // URL para el tipo de usuario 4
            5 => "../../../Vista/ALMACENISTA/index_ALMACENISTA.php" // URL para el tipo de usuario 5
        ];

        echo json_encode([  // Enviar la respuesta en formato JSON
            "success" => true, // Indicar que la operación fue exitosa
            "message" => "Se ha Guardado Correctamente.",
            "redirect" => $urls[$RetornarTipoUsuario] ?? "../../../index.php" // Redireccionar a la página de inicio
        ]);
    } catch (Exception $e) {
        // Revertir la transacción en caso de error
        $conexion->rollback();
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Método no permitido.'
    ]);
}

// Función para enviar correo electrónico
function enviarCorreo($FchEnvio, $idSolicitud, $conexion) {
    try {
        // Generar el PDF y obtener el nombre del archivo generado
        $resultadoPDF = generarPDF($conexion, $idSolicitud);

        // Verificar si se generó correctamente el PDF
        if (is_array($resultadoPDF) && !$resultadoPDF['success']) {
            throw new Exception("Error al generar el PDF: " . $resultadoPDF['message']);
        }

        // Obtener el nombre del PDF generado
        $nombrePDF = $resultadoPDF;
        
        $rutaPDF = "../../../pdfs/" . $nombrePDF;
        
        // Configurar PHPMailer
        // $mail = new PHPMailer(true);
        // $mail->SMTPDebug = 0;
        // $mail->isSMTP();
        // $mail->Host = 'mail.grupopryse.mx';
        // $mail->SMTPAuth = true;
        // $mail->Username = 'tecnico.ti@grupopryse.mx';
        // $mail->Password = 'vi3ORwd,E-TE'; // Usar variable de entorno para la contraseña
        // $mail->SMTPSecure = 'ssl';
        // $mail->Port = 465;
        // $mail->CharSet = 'UTF-8';
    
        // Configurar remitente y destinatario
        // $mail->setFrom('tecnico.ti@grupopryse.mx', 'Tecnico Pryse');
        // $mail->addAddress('karen.lopez.pryse@gmail.com');

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = 'tls';
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        // Dirección de correo electrónico de Gmail
        $mail->Username = 'SGMO201792@upemor.edu.mx';
        // Contraseña de Gmail o App Password
        $mail->Password = 'SIGM071001'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Configurar el remitente y el destinatario del correo
        $mail->setFrom('SGMO201792@upemor.edu.mx', 'Moises Silva Gonzalez');
        $mail->addAddress('mochito619@gmail.com');

        // Adjuntar archivo si existe
        if (file_exists($rutaPDF)) {
            $mail->addAttachment($rutaPDF);
        } else {
            throw new Exception("El archivo PDF no existe: $rutaPDF");
        }
    
        // Configurar correo
        $mail->isHTML(true);
        $mail->Subject = 'Nueva Requisición';
        $mensaje = '<html lang="es"><head><meta charset="UTF-8">';
        $mensaje .= '<style>body { font-family: Arial, sans-serif; }</style></head><body>';
        $mensaje .= '<h1>Grupo Pryse Seguridad Privada S.A. de C.V.</h1>';
        $mensaje .= '<p>Hola,</p>';
        $mensaje .= '<p>Se ha hecho una nueva requisición a las: ' . htmlspecialchars($FchEnvio) . '</p>';
        $mensaje .= '<p>Número de la Requisición: ' . htmlspecialchars($idSolicitud) . '</p>';
        $mensaje .= '<p>Puedes descargar el PDF <a href="https://almacen.grupopryse.mx/pdfs/' . htmlspecialchars(basename($nombrePDF)) . '">aquí</a>.</p>';
        $mensaje .= '</body></html>';
        $mail->Body = $mensaje;
        $mail->AltBody = 'Número de la Requisición: ' . $idSolicitud . '. Puedes descargar el PDF aquí: https://almacen.grupopryse.mx/pdfs/' . basename($nombrePDF);
    
        // Enviar el correo
        $mail->send();
        echo 'Correo enviado exitosamente.';

        return true;
    } catch (Exception $e) {
        return ["success" => false, "message" => $e->getMessage()];
    }
}
?>